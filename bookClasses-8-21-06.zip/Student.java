public class Student
{
  ///////// fields ///////////
  private String name;
  private double grade1;
  private double grade2;
  private double grade3;
  
  ////////////// constructor /////////////
  public Student(String theName, double theGrade1, 
                 double theGrade2, double theGrade3)
  {
    this.name = theName;
    this.grade1 = theGrade1;
    this.grade2 = theGrade2;
    this.grade3 = theGrade3;
  }
  public Student(String theName)
  {
    this.name = theName;
  }
  
  //////////// methods //////////////////
  public String toString()
  {
    return "Student object named: " + this.name +
      " average " + getAverage();
  }
  
  public boolean setGrade1(double theGrade1)
  {
    boolean flag = true;
    if ( theGrade1 < 0)
      flag = false;
    else
      this.grade1 = theGrade1;
    return flag;
  }
  
  public boolean setGrade2(double theGrade2)
  {
    boolean flag = true;
    if ( theGrade2 < 0)
      flag = false;
    else
      this.grade2 = theGrade2;
    return flag;
  }
  
  public boolean setGrade3(double theGrade3)
  {
    boolean flag = true;
    if ( theGrade3 < 0)
      flag = false;
    else
      this.grade3 = theGrade3;
    return flag;
  }
      
  
  public double getAverage()
  {
    return (this.grade1 + this.grade2 + this.grade3) / 3.0;
  }
  
  public static void main(String[] args)
  {
    Student tom = new Student("Tom");
    boolean flag = tom.setGrade1(90);
    System.out.println(flag);
    flag = tom.setGrade2(80);
    System.out.println(flag);
    flag = tom.setGrade3(-30);
    System.out.println(flag);
    System.out.println(tom);
    Student sue = new Student("Sue");
    System.out.println(sue);
    Class class1 = tom.getClass();
    System.out.println(class1);
    Class class2 = sue.getClass();
    System.out.println(class2);
    Student barb = new Student("Barb",70.3,80.2, 90);
    System.out.println(barb);
  }
}