public class SlowTurtle extends Turtle
{
  
  public SlowTurtle(World w)
  {
    super(w);
  }
  
  public void forward() 
  {
    super.forward(50);
  }
  
  public void forward(int amount)
  {
    super.forward(amount/2);
  }
  
  public static void main(String[] args)
  {
    World w1 = new World();
    SlowTurtle t1 = new SlowTurtle(w1);
    Turtle t2 = new Turtle(w1);
    t1.forward();
    t2.forward();
    t1.turnLeft();
    t2.turnLeft();
    t1.forward(50);
    t2.forward(50);
  }
}